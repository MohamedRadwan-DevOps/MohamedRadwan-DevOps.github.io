﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Common;

namespace MVP
{
    public partial class Search : System.Web.UI.Page, IView
    {

        private Presenter.Presenter presenter;

        public Search()
        {

            this.presenter = new Presenter.Presenter(this);

        }

       #region IView Members



        public string SearchCriteria
        {

            get { return this.tbSearchCriteria.Text; }

        }

        public List<string> Results
        {

            set
            {
                this.dlResult.DataSource = null;
                this.dlResult.DataBind();

                List<string> results = new List<string>(value);
                this.dlResult.DataSource = results;
                this.dlResult.DataBind();
            }
        }

        #endregion

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.presenter.Search();
        }

    }
   
}