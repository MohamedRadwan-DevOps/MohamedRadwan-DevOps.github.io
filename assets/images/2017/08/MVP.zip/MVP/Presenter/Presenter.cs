﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Common;

namespace Presenter
{
    public class Presenter
    {
        private readonly IView view;
        private Model.Model model = new Model.Model();

        public Presenter(IView view)
        {
            this.view = view;
        }

        public void Search()
        {
            this.view.Results = this.model.Search(this.view.SearchCriteria);
        }
    }
}
