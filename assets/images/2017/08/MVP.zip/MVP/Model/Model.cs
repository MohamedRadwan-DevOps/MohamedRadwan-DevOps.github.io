﻿using System.Collections.Generic;

namespace Model
{
    /// <summary>
    /// This class should encapsulate the underling database or web services
    /// </summary>
    public class Model
    {
        public List<string> Search(string searchCriteria)
        {
            //Now you suppose search by SearchCriteria and create a collection that has your search result
            List<string> result =new List<string>();
            result.Add("Result 1");
            result.Add("Result 2");
            result.Add("Result 3");
            return result;

        }
    }
}
